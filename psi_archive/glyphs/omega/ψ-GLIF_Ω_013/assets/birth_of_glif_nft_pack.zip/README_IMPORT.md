# Birth of Glif NFT — Integration Pack

Copy into `~/psi_lab/`:

```bash
cd ~/psi_lab
cp -R /path/to/this_pack/* .
python3 psi_archive/glyphs/omega/ψ-GLIF_Ω_013/scripts/psi_glif_omega_013.py
git status --short
```

Recommended first commit:

```bash
git add index/GLYPH_ORIGIN_CHAIN.md psi_archive/glyphs/omega/ψ-GLIF_Ω_013
git commit -m "Add Birth of Glif NFT root node"
git push
```

Place PNG/MP4 assets under:

```text
psi_archive/glyphs/omega/ψ-GLIF_Ω_013/assets/
```
